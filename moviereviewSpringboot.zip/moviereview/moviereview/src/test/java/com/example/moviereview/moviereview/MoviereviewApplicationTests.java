package com.example.moviereview.moviereview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviereviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
