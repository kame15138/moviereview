insert into User values(1,'Kamesh','kamesh2705','user')
insert into User values(2,'Rahul','java','user')
insert into User values(3,'admin','admin','admin')
insert into movie values(1,'Bigil','Drama','Vijay','Football coach guides women team','Tamil')
