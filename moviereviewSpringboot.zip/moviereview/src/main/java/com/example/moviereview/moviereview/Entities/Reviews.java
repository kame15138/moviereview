package com.example.moviereview.moviereview.Entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Reviews {

	@Id
	private int id;
	private String comment;
	private int rating;
	
	@JsonIgnore
	@ManyToOne
	private Movie movie;
	@JsonIgnore
	@ManyToOne
	private User user;
	
	
	public Reviews() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Reviews(int id, String comment, int rating, Movie movie, User user) {
		super();
		this.id = id;
		this.comment = comment;
		this.rating = rating;
		this.movie = movie;
		this.user = user;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}


	public int getRating() {
		return rating;
	}


	public void setRating(int rating) {
		this.rating = rating;
	}


	public Movie getMovie() {
		return movie;
	}


	public void setMovie(Movie movie) {
		this.movie = movie;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}

	
}
