package com.example.moviereview.moviereview.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.moviereview.moviereview.Entities.User;
import com.example.moviereview.moviereview.Repository.UserRepository;
import com.example.moviereview.moviereview.Service.ServiceImpl;

@CrossOrigin("http:localhost:4200")
@RestController
public class LoginController {
	
	@Autowired
	private  ServiceImpl service;
	
	@Autowired
	private UserRepository userRepo;

	@PostMapping("/userLogin")
	public User LoginController(@RequestBody User user)
	{
		User userLogged=service.AuthenticateUser(user);
        return userLogged;
		
	}
	
	

}
