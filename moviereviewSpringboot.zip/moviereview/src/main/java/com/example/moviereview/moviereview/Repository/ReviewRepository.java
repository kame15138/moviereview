package com.example.moviereview.moviereview.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.moviereview.moviereview.Entities.Movie;
import com.example.moviereview.moviereview.Entities.Reviews;

public interface ReviewRepository  extends JpaRepository <Reviews,Integer>{

}
