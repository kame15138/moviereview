package com.example.moviereview.moviereview.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.moviereview.moviereview.Entities.User;

@Repository
public interface UserRepository extends JpaRepository <User,Integer> {
	
	@Query(value="select * from User where user_name=?1 and user_password=?2 and user_role=?3",nativeQuery=true)
	public  User authenticateUser(String user_name,String user_password,String user_role);

}
