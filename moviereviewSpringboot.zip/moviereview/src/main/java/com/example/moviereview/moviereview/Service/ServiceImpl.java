package com.example.moviereview.moviereview.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.moviereview.moviereview.Entities.User;
import com.example.moviereview.moviereview.Repository.UserRepository;


@Component
public class ServiceImpl {

	
	@Autowired
	private UserRepository userRepo;
	
		// TODO Auto-generated constructor stub
		public  User AuthenticateUser(User user)
				{
			
			System.out.print(user.getUser_name()+user.getPassword()+ user.getRole());
			           return userRepo.authenticateUser(user.getUser_name(), user.getPassword(), user.getRole());
			          
			
				}
	

}
