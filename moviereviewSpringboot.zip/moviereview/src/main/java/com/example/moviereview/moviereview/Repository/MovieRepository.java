package com.example.moviereview.moviereview.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.moviereview.moviereview.Entities.Movie;
import com.example.moviereview.moviereview.Entities.User;

public interface MovieRepository extends JpaRepository <Movie,Integer> {

}
