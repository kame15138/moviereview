package com.example.moviereview.moviereview.Entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Movie {

	@Id
	@GeneratedValue
	private int id;
	private String movie_title;
	private String movie_genre;
	private String movie_cast;
	private String movie_plot;
	private String movie_laguage;
	@OneToMany
	private List<Reviews> reviews;
	public Movie(int id, String movie_title, String movie_genre, String movie_cast, String movie_plot,
			String movie_laguage) {
		super();
		this.id = id;
		this.movie_title = movie_title;
		this.movie_genre = movie_genre;
		this.movie_cast = movie_cast;
		this.movie_plot = movie_plot;
		this.movie_laguage = movie_laguage;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMovie_title() {
		return movie_title;
	}
	public void setMovie_title(String movie_title) {
		this.movie_title = movie_title;
	}
	public String getMovie_genre() {
		return movie_genre;
	}
	public void setMovie_genre(String movie_genre) {
		this.movie_genre = movie_genre;
	}
	public String getMovie_cast() {
		return movie_cast;
	}
	public void setMovie_cast(String movie_cast) {
		this.movie_cast = movie_cast;
	}
	public String getMovie_plot() {
		return movie_plot;
	}
	public void setMovie_plot(String movie_plot) {
		this.movie_plot = movie_plot;
	}
	public String getMovie_laguage() {
		return movie_laguage;
	}
	public void setMovie_laguage(String movie_laguage) {
		this.movie_laguage = movie_laguage;
	}
	 
	

}
